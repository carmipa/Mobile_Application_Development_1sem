import 'react-native-gesture-handler';
import Routes from "./src/routes/stack.routes";

export default function App() {
  return (
    <Routes />
  );
}
