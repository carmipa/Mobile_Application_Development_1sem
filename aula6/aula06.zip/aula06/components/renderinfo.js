import {Text} from 'react-native';

export default (props) =>{
    return(
        <Text>{props.nameAluno} - {props.eAluno}</Text>
    )
}